# Internship Assignment

Build a user registration + login system using:
- Node.js frontend
- Python backend
- MySQL/PostgreSQL
